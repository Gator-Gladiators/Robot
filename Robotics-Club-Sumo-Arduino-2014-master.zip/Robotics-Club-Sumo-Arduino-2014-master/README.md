Robotics-Club-Sumo-Arduino-2014
===============================

Arduino code for mini sumo robot 
Drexel University

Get the arduno IDE here:
http://arduino.cc/en/main/software

To use this please download this library and add it into your arduino IDE:    
https://github.com/pololu/zumo-shield

You will also need this library for the accelerometer:  
https://github.com/pololu/LSM303

